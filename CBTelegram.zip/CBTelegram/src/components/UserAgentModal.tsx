import { useState } from 'react';

interface UserAgentModalProps {
  userAgent: string;
  onClose: () => void;
}

export default function UserAgentModal({ userAgent, onClose }: UserAgentModalProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(userAgent);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Fallback
      const textarea = document.createElement('textarea');
      textarea.value = userAgent;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-[#16213e] border border-gray-700/50 rounded-xl p-6 max-w-lg w-full shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-semibold text-lg">User Agent Details</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-700/30">
          <p className="text-gray-300 text-sm font-mono break-all leading-relaxed">{userAgent}</p>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <button
            onClick={handleCopy}
            className="bg-teal-600 hover:bg-teal-700 text-white text-xs font-medium px-4 py-2 rounded-md transition-all"
          >
            {copied ? 'Copied!' : 'Copy'}
          </button>
          <button
            onClick={onClose}
            className="bg-gray-600 hover:bg-gray-500 text-white text-xs font-medium px-4 py-2 rounded-md transition-all"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
