import { Toast } from '../types';

interface ToastContainerProps {
  toasts: Toast[];
  onRemove: (id: string) => void;
}

export default function ToastContainer({ toasts, onRemove }: ToastContainerProps) {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-[100] flex flex-col gap-2 max-w-sm">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg shadow-xl border backdrop-blur-sm animate-slide-in cursor-pointer ${
            toast.type === 'success'
              ? 'bg-green-900/90 border-green-500/40 text-green-200'
              : toast.type === 'error'
              ? 'bg-red-900/90 border-red-500/40 text-red-200'
              : 'bg-blue-900/90 border-blue-500/40 text-blue-200'
          }`}
          onClick={() => onRemove(toast.id)}
        >
          <span className="text-lg">
            {toast.type === 'success' ? '✓' : toast.type === 'error' ? '✕' : 'ℹ'}
          </span>
          <span className="text-sm font-medium">{toast.message}</span>
        </div>
      ))}
    </div>
  );
}
