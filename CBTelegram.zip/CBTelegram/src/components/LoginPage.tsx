import { useState } from 'react';
import { login } from '../services/auth';

interface LoginPageProps {
  onLogin: (username: string) => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username.trim() || !password.trim()) {
      setError('Please fill in all fields');
      return;
    }

    setLoading(true);

    // Small delay for UX, then validate
    setTimeout(() => {
      const result = login(username.trim(), password);
      if (result.success) {
        onLogin(username.trim());
      } else {
        setError(result.error || 'Authentication failed');
        setLoading(false);
      }
    }, 400);
  };

  return (
    <div className="min-h-screen bg-[#1a1a2e] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-[#16213e] rounded-2xl shadow-2xl p-8 border border-gray-700/50">
          {/* Key Icon */}
          <div className="flex justify-center mb-6">
            <svg
              width="80"
              height="80"
              viewBox="0 0 80 80"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle cx="30" cy="35" r="18" stroke="#4ade80" strokeWidth="3" fill="none" />
              <circle cx="30" cy="35" r="8" fill="#4ade80" opacity="0.3" />
              <line x1="45" y1="35" x2="70" y2="15" stroke="#2dd4bf" strokeWidth="3" strokeLinecap="round" />
              <line x1="60" y1="22" x2="68" y2="28" stroke="#2dd4bf" strokeWidth="3" strokeLinecap="round" />
              <line x1="55" y1="26" x2="62" y2="32" stroke="#2dd4bf" strokeWidth="3" strokeLinecap="round" />
            </svg>
          </div>

          <h1 className="text-white text-2xl font-bold text-center tracking-wider mb-8">
            ADMIN PANEL
          </h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-gray-400 text-xs tracking-widest uppercase mb-2">
                Username
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-[#e8e8e8] text-gray-800 rounded-md px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400/50 transition-all"
                placeholder="Enter username"
                autoComplete="username"
              />
            </div>

            <div>
              <label className="block text-gray-400 text-xs tracking-widest uppercase mb-2">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#e8e8e8] text-gray-800 rounded-md px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400/50 transition-all"
                placeholder="Enter password"
                autoComplete="current-password"
              />
            </div>

            {error && (
              <div className="text-red-400 text-sm text-center bg-red-400/10 py-2 rounded-md border border-red-500/20">
                {error}
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={loading}
                className="bg-transparent border border-gray-500 text-white px-8 py-2 rounded-md hover:bg-white/10 transition-all text-sm tracking-wider font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    Verifying...
                  </span>
                ) : (
                  'ENTER'
                )}
              </button>
            </div>
          </form>

          <div className="mt-8 text-center">
            <span className="inline-block border border-yellow-500/50 text-yellow-400 text-xs px-4 py-2 rounded-md">
              Admin Dashboard Panel
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
