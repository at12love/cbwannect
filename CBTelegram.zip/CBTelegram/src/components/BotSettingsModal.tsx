import { useState, useEffect } from 'react';
import { getBotConfig, saveBotConfig } from '../services/telegram';

interface BotSettingsModalProps {
  onClose: () => void;
  onSuccess: (message: string) => void;
}

export default function BotSettingsModal({ onClose, onSuccess }: BotSettingsModalProps) {
  const [token, setToken] = useState('');
  const [chatId, setChatId] = useState('');

  useEffect(() => {
    const config = getBotConfig();
    if (config) {
      setToken(config.token);
      setChatId(config.chatId);
    }
  }, []);

  const handleSave = () => {
    saveBotConfig({ token, chatId });
    onSuccess('Bot configuration saved');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-[#16213e] border border-gray-700/50 rounded-xl p-6 max-w-md w-full shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-white font-semibold text-lg mb-4">Telegram Bot Settings</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-gray-400 text-xs mb-1">Bot Token</label>
            <input type="text" value={token} onChange={e => setToken(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white text-sm" />
          </div>
          <div>
            <label className="block text-gray-400 text-xs mb-1">Chat ID</label>
            <input type="text" value={chatId} onChange={e => setChatId(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white text-sm" />
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-6">
          <button onClick={onClose} className="bg-gray-600 px-4 py-2 rounded text-white text-xs">Cancel</button>
          <button onClick={handleSave} className="bg-teal-600 px-4 py-2 rounded text-white text-xs">Save Settings</button>
        </div>
      </div>
    </div>
  );
}
