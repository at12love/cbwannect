export interface Entry {
  id: string;
  index: number;
  activity: string;
  ip: string;
  userAgent: string;
  status: 'waiting' | 'verified' | 'rejected';
  seedPhrase: string;
  createdAt: string;
  referer?: string;
}

export type EntryStatus = Entry['status'];

export interface AdminCredentials {
  username: string;
  password: string;
}

export interface Session {
  username: string;
  loggedInAt: string;
  lastLogin: string | null;
}

export interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

export type Page = 'login' | 'dashboard';
