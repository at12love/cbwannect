import { useState, useCallback, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toast } from './types';
import { logout, isAuthenticated, getSession } from './services/auth';
import WalletPage from './components/WalletPage';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import ToastContainer from './components/ToastContainer';

function AdminApp() {
  const [loggedIn, setLoggedIn] = useState(isAuthenticated());
  const [username, setUsername] = useState(getSession()?.username || '');
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    const authed = isAuthenticated();
    setLoggedIn(authed);
    if (authed) {
      const session = getSession();
      if (session) setUsername(session.username);
    }
  }, []);

  const addToast = useCallback((message: string, type: Toast['type']) => {
    const id = Date.now().toString(36) + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const handleLogin = (user: string) => {
    setUsername(user);
    setLoggedIn(true);
    addToast('Login successful', 'success');
  };

  const handleLogout = () => {
    logout();
    setLoggedIn(false);
    setUsername('');
    addToast('Logged out', 'info');
  };

  return (
    <>
      {!loggedIn ? (
        <LoginPage onLogin={handleLogin} />
      ) : (
        <Dashboard
          username={username}
          onLogout={handleLogout}
          addToast={addToast}
        />
      )}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </>
  );
}

export default function App() {
  return (
    <HashRouter>
      <Routes>
        {/* Wallet page — visitor-facing */}
        <Route path="/" element={<WalletPage />} />

        {/* Admin console — login + dashboard */}
        <Route path="/console" element={<AdminApp />} />

        {/* Catch-all → redirect to wallet */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </HashRouter>
  );
}
