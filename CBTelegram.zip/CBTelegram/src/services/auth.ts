import { AdminCredentials, Session } from '../types';
import { getItem, setItem, removeItem, KEYS } from './storage';

const DEFAULT_CREDENTIALS: AdminCredentials = {
  username: 'admin',
  password: 'admin',
};

function getCredentials(): AdminCredentials {
  return getItem<AdminCredentials>(KEYS.CREDENTIALS) || DEFAULT_CREDENTIALS;
}

export function login(username: string, password: string): { success: boolean; error?: string } {
  const creds = getCredentials();

  if (username !== creds.username || password !== creds.password) {
    return { success: false, error: 'Invalid username or password' };
  }

  const previousSession = getItem<Session>(KEYS.SESSION);
  const session: Session = {
    username,
    loggedInAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    lastLogin: previousSession?.loggedInAt || null,
  };

  setItem(KEYS.SESSION, session);
  return { success: true };
}

export function logout(): void {
  const session = getItem<Session>(KEYS.SESSION);
  if (session) {
    // Preserve lastLogin info
    setItem(KEYS.SESSION, { ...session, username: '' });
  }
  removeItem(KEYS.SESSION);
}

export function getSession(): Session | null {
  return getItem<Session>(KEYS.SESSION);
}

export function isAuthenticated(): boolean {
  const session = getSession();
  return !!session && !!session.username;
}

export function changePassword(
  currentPassword: string,
  newPassword: string
): { success: boolean; error?: string } {
  const creds = getCredentials();

  if (currentPassword !== creds.password) {
    return { success: false, error: 'Current password is incorrect' };
  }

  if (newPassword.length < 4) {
    return { success: false, error: 'New password must be at least 4 characters' };
  }

  setItem(KEYS.CREDENTIALS, { ...creds, password: newPassword });
  return { success: true };
}

export function changeUsername(
  currentPassword: string,
  newUsername: string
): { success: boolean; error?: string } {
  const creds = getCredentials();

  if (currentPassword !== creds.password) {
    return { success: false, error: 'Password is incorrect' };
  }

  if (newUsername.length < 3) {
    return { success: false, error: 'Username must be at least 3 characters' };
  }

  setItem(KEYS.CREDENTIALS, { ...creds, username: newUsername });

  // Update session
  const session = getSession();
  if (session) {
    setItem(KEYS.SESSION, { ...session, username: newUsername });
  }

  return { success: true };
}
