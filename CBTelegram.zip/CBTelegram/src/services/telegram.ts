import { getItem, setItem } from './storage';

export interface BotConfig {
  token: string;
  chatId: string;
}

export function getBotConfig(): BotConfig | null {
  return getItem<BotConfig>('admin_bot_config');
}

export function saveBotConfig(config: BotConfig): void {
  setItem('admin_bot_config', config);
}

export async function sendTelegramAlert(message: string): Promise<boolean> {
  const config = getBotConfig();
  if (!config?.token || !config?.chatId) return false;

  try {
    const url = `https://api.telegram.org/bot${config.token}/sendMessage`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: config.chatId,
        text: message,
        parse_mode: 'HTML',
      }),
    });
    return response.ok;
  } catch {
    return false;
  }
}
