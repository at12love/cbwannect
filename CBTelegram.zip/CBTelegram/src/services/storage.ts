// Storage keys
const KEYS = {
  CREDENTIALS: 'admin_credentials',
  SESSION: 'admin_session',
  ENTRIES: 'admin_entries',
  ENTRY_COUNTER: 'admin_entry_counter',
  NOTIFICATIONS: 'admin_notifications_enabled',
} as const;

export function getItem<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function setItem<T>(key: string, value: T): void {
  localStorage.setItem(key, JSON.stringify(value));
}

export function removeItem(key: string): void {
  localStorage.removeItem(key);
}

export { KEYS };
